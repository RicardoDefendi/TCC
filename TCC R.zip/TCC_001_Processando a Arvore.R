# carrega a biblioteca para tranblhar com o arquivo Excel
library(readxl) 
meu_arquivo <- read_excel("baseTCC.xlsx") #Carregar a base de dados

meu_arquivo %>% head
meu_arquivo %>% str


#############################################
# Vamos construir a árvore de classificação #
#Arvoce com todos os campos
arvore <- rpart::rpart(Sucesso ~ CategoriaAB + Cliente_Novo + Setor_Financeiro_Serviços + Há_Budget + Sponsor_Aprovou + Há_Prazo_Implantação + Há_Concorrência + Há_Mapeamento + OrigemOpoBase + É_Renovação + CompanhaMKT + AbertaAte6Meses ,
                       data=meu_arquivo,
                       parms = list(split = 'gini'), # podemos trocar para  'information'
                       method='class' # Essa opção indica que a resposta é qualitativa
)

#########################
# Visualizando a árvore #

# Definindo uma paleta de cores
paleta = scales::viridis_pal(begin=.75, end=1)(20)
# Plotando a árvore
rpart.plot::rpart.plot(arvore, box.palette = paleta) # Paleta de cores



#Arvore com as variaveis do cliente
arvoreCli <- rpart::rpart(Sucesso ~  CategoriaAB + Cliente_Novo + Setor_Financeiro_Serviços + Há_Budget + Sponsor_Aprovou+  Há_Prazo_Implantação   ,
                       data=meu_arquivo,
                       parms = list(split = 'information'), # podemos trocar para  'information'
                       method='class' # Essa opção indica que a resposta é qualitativa
)
rpart.plot::rpart.plot(arvoreCli, box.palette = paleta) # Paleta de cores

#Arvore com as variaveis da negociação
arvoreOPO <- rpart::rpart(Sucesso ~ Há_Concorrência + Há_Mapeamento + OrigemOpoBase + É_Renovação + CompanhaMKT + AbertaAte6Meses  ,
                          data=meu_arquivo,
                          parms = list(split = 'gini'), # podemos trocar para  'information'
                          method='class' # Essa opção indica que a resposta é qualitativa
)
rpart.plot::rpart.plot(arvoreOPO, box.palette = paleta) # Paleta de cores


#Arvore com as variaveis da negociação
arvorePerda <- rpart::rpart(Sucesso ~ Há_Budget + Sponsor_Aprovou + É_Renovação + CompanhaMKT + AbertaAte6Meses ,
                          data=meu_arquivo,
                          parms = list(split = 'gini'), # podemos trocar para  'information'
                          method='class' # Essa opção indica que a resposta é qualitativa
)
rpart.plot::rpart.plot(arvorePerda, box.palette = paleta) # Paleta de cores



##############################
# Avaliação básica da árvore #

# Predizendo com a árvore

# Probabilidade de sobreviver
prob = predict(arvore, meu_arquivo)

# Classificação dos sobreviventes
class = prob[,2]>.5
sum(class)
# Matriz de confusão
tab <- table(class, meu_arquivo$Sucesso)
tab

acc <- (tab[1,1] + tab[2,2])/ sum(tab)
acc
sprintf('Acurácia na base de treino: %s ', percent(acc))

